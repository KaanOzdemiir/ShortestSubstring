import UIKit

let str = "bcaacbc"


func isInConstraints(s: String) -> Bool {
    
    let characterset = CharacterSet.letters
    
    let isItLetter = s.rangeOfCharacter(from: characterset.inverted) != nil
    let sizeConstraint = (1 <= s.count && Double(s.count) <= pow(10, 5))

    if s.contains(where: {!$0.isASCII || isItLetter || !sizeConstraint}) {
        return false
    }
    return true
}

func shortestSubstring(s: String) -> Int { // Write your code here
    var searchCharacters: [Character] = []

    var result: [Character] = []

    str.forEach { (ch) in
        
        if !searchCharacters.contains(ch) {
            result.append(ch)
        }
        searchCharacters.append(ch)
    }
    print(result, result.count)
    print("\(String(result)) is a substring that contains all the characters in s")
    return result.count
}

if isInConstraints(s: str) {
    shortestSubstring(s: str)
}else {
    print("\(str) is not in constraints")
}
